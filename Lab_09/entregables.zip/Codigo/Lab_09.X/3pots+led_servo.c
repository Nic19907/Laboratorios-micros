/*
 * File:   3pots+led_servo.c
 * Author: NicoU
 *
 * Created on 10 de octubre de 2021, 11:39 PM
 */


#include <xc.h>

void main(void) {
    return;
}
